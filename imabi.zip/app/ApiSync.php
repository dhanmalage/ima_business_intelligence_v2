<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApiSync extends Model
{
    //
}
