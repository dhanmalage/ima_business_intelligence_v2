

<?php $__env->startSection('content'); ?>

    <div class="page-title">
        <div class="title_left">
            <h3>All Events <small>Summary Report</small></h3>
        </div>
    </div>

    <div class="clearfix"></div>

    <?php if(!empty($flashMsg)): ?>
        <div class="alert alert-success"> <?php echo e($flashMsg); ?></div>
    <?php endif; ?>

    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>All IMA Events <small>Summary</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                        This is a summary report of all events in IMA
                    </p>
                    <table <?php if(auth()->check() && auth()->user()->hasAnyRole('super_admin|administrator')): ?> id="datatable-buttons" <?php else: ?> id="datatable" <?php endif; ?> class="table table-striped table-bordered dt-responsive nowrap">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Event Name</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Attendees</th>
                                <th>Tickets</th>
                                <th>Paid Total</th>
                                <th>Status</th>

                                <?php if(auth()->check() && auth()->user()->hasRole('super_admin|administrator')): ?>
                                    <th>Actions</th>
                                <?php endif; ?>

                            </tr>
                        </thead>

                        <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(url('ima-event/' . $event->id)); ?>"><?php echo e($i); ?></a></td>
                                <td><a href="<?php echo e(url('ima-event/' . $event->id)); ?>"><?php echo e($event->event_name); ?></a></td>
                                <td><a href="<?php echo e(url('ima-event/' . $event->id)); ?>"><?php echo e(date('d-m-Y', strtotime($event->start_date))); ?></a></td>
                                <td><a href="<?php echo e(url('ima-event/' . $event->id)); ?>"><?php echo e($event->event_start_time); ?></a></td>
                                <td><a href="<?php echo e(url('ima-event/' . $event->id)); ?>"><?php echo e($event->imabi_attendees_complete); ?></a></td>
                                <td><a href="<?php echo e(url('ima-event/' . $event->id)); ?>"><?php echo e($event->reg_limit); ?></a></td>
                                <td><a href="<?php echo e(url('ima-event/' . $event->id)); ?>">$<?php echo e(number_format( $event->member_price * $event->imabi_attendees_complete , 2 , '.' , ',' )); ?></a></td>

                                <td>
                                    <a href="/ima-event/<?php echo e($event->id); ?>" class="event-status">
                                        <?php if($event->event_status == "Open"): ?>
                                            <span class="label label-success"><?php echo e($event->event_status); ?></span>
                                        <?php endif; ?>
                                        <?php if($event->event_status == "Closed"): ?>
                                            <span class="label label-info"><?php echo e($event->event_status); ?></span>
                                        <?php endif; ?>
                                        <?php if($event->event_status == "Postponed"): ?>
                                            <span class="label label-warning"><?php echo e($event->event_status); ?></span>
                                        <?php endif; ?>
                                        <?php if($event->event_status == "Cancelled"): ?>
                                            <span class="label label-danger"><?php echo e($event->event_status); ?></span>
                                        <?php endif; ?>
                                    </a>
                                </td>
                                <td>
                                    <?php if(auth()->check() && auth()->user()->hasRole('super_admin')): ?>
                                        <a href="<?php echo e(url('event-settings/' . $event->setting_id . '/edit')); ?>" class="ima-color-red table-action-button" title="Edit"><i class="fa fa-pencil"></i></a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(url('ima-event/ima-event-details-print/' . $event->id)); ?>" class="ima-color-red table-action-button" target="_blank" title="Print"><i class="fa fa-print"></i></a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>