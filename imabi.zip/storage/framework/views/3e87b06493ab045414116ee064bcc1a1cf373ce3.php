

<?php $__env->startSection('content'); ?>

    <div class="clearfix"></div>

    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>IMA Event Donations Summary</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                        This is a summary report of all event based donations
                    </p>
                    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Reference</th>
                            <th>Event</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $event_donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(url('event-donation-details/' . $donation->id)); ?>"><?php echo e($i); ?></a></td>
                                <td><a href="<?php echo e(url('event-donation-details/' . $donation->id)); ?>"><?php echo e($donation->reference); ?></a></td>
                                <td><a href="<?php echo e(url('event-donation-details/' . $donation->id)); ?>"><?php echo e($donation->event_name); ?></a></td>
                                <td class="text-right"><a href="<?php echo e(url('event-donation-details/' . $donation->id)); ?>"><?php echo e(number_format($donation->donation, 2 , '.' , ',' )); ?></a></td>
                                <td><a href="<?php echo e(url('event-donation-details/' . $donation->id)); ?>"><?php echo e(date('d-m-Y', strtotime($donation->date))); ?></a></td>
                                <td class="text-center">
                                    <a href="<?php echo e(url('event-donation-details/' . $donation->id)); ?>" class="" title="View"><span class="label btn-success"><i class="fa fa-search"></i> View</span></a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>