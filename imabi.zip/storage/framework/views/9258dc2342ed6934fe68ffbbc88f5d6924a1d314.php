<?php $__env->startSection('content'); ?>

    <div class="clearfix"></div>

    <div class="col-md-6 col-sm-6 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Events history as at <?php $__currentLoopData = $last_event_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eve_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e(date('d/m/Y', strtotime($eve_detail->created_at))); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <ul class="list-unstyled timeline">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="block">
                                <div class="tags">
                                    <a href="/ima-event/<?php echo e($event->id); ?>" class="tag ima-bg-orange">
                                        <span>Event</span>
                                    </a>
                                </div>
                                <div class="block_content position-relative dashboard-history-wrap">
                                    <div class="num-new-records-events"><span class="home-attendees-num"><?php echo e($event->imabi_attendees_complete); ?> / <?php echo e($event->imabi_attendees_complete + $event->imabi_attendees_incomplete); ?></span><span>Attendees / Total</span></div>
                                    <h2 class="title home-event-title">
                                        <a href="/ima-event/<?php echo e($event->id); ?>">
                                            <?php echo e($event->event_name); ?>

                                            <?php if($event->event_status == "Open"): ?>
                                                <span class="label label-success"><?php echo e($event->event_status); ?></span>
                                            <?php endif; ?>
                                            <?php if($event->event_status == "Closed"): ?>
                                                <span class="label label-info"><?php echo e($event->event_status); ?></span>
                                            <?php endif; ?>
                                            <?php if($event->event_status == "Postponed"): ?>
                                                <span class="label label-warning"><?php echo e($event->event_status); ?></span>
                                            <?php endif; ?>
                                            <?php if($event->event_status == "Cancelled"): ?>
                                                <span class="label label-danger"><?php echo e($event->event_status); ?></span>
                                            <?php endif; ?>
                                        </a>
                                    </h2>
                                    <p class="excerpt dashboard-import-note"><?php echo e(date('d/m/Y', strtotime($event->start_date))); ?> at <?php echo e($event->start_time); ?></p>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>
        </div>
    </div>

    <div class="col-md-6 col-sm-6 col-xs-12">
        <div class="x_panel">
            <div class="x_title">
                <h2>Data update history</h2>
                <ul class="nav navbar-right panel_toolbox">
                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                    </li>
                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="x_content">
                <ul class="list-unstyled timeline">
                    <?php $__currentLoopData = $api_sync_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($record->event_details != null): ?>
                            <li>
                                <div class="block">
                                    <div class="tags">
                                        <a href="" class="tag ima-bg-green">
                                            <span>API Sync</span>
                                        </a>
                                    </div>
                                    <div class="block_content position-relative dashboard-history-wrap">
                                        <div class="num-new-records"><span class="numberCircle"><?php echo e($record->event_details); ?></span><span>New Records</span>
                                        </div>
                                        <h2 class="title">
                                            <a>Events Data Sync</a>
                                        </h2>
                                        <div class="byline">
                                            <span><?php echo e($record->created_at); ?></span> by <a>System automation</a>
                                        </div>
                                        <p class="excerpt dashboard-file-name">New Data Sync: <span> System generated automatically</span></p>
                                    </div>
                                </div>
                            </li>
                        <?php endif; ?>
                            <?php if($record->attendees != null): ?>
                                <li>
                                    <div class="block">
                                        <div class="tags">
                                            <a href="" class="tag ima-bg-green">
                                                <span>API Sync</span>
                                            </a>
                                        </div>
                                        <div class="block_content position-relative dashboard-history-wrap">
                                            <div class="num-new-records"><span class="numberCircle"><?php echo e($record->attendees); ?></span><span>New Records</span>
                                            </div>
                                            <h2 class="title">
                                                <a>Attendees Data Sync</a>
                                            </h2>
                                            <div class="byline">
                                                <span><?php echo e($record->created_at); ?></span> by <a>System automation</a>
                                            </div>
                                            <p class="excerpt dashboard-file-name">New Data Sync: <span> System generated automatically</span></p>
                                        </div>
                                    </div>
                                </li>
                            <?php endif; ?>
                            <?php if($record->event_time != null): ?>
                                <li>
                                    <div class="block">
                                        <div class="tags">
                                            <a href="" class="tag ima-bg-green">
                                                <span>API Sync</span>
                                            </a>
                                        </div>
                                        <div class="block_content position-relative dashboard-history-wrap">
                                            <div class="num-new-records"><span class="numberCircle"><?php echo e($record->event_time); ?></span><span>New Records</span>
                                            </div>
                                            <h2 class="title">
                                                <a>Event Times Update</a>
                                            </h2>
                                            <div class="byline">
                                                <span><?php echo e($record->created_at); ?></span> by <a>System automation</a>
                                            </div>
                                            <p class="excerpt dashboard-file-name">New Data Sync: <span> System generated automatically</span></p>
                                        </div>
                                    </div>
                                </li>
                            <?php endif; ?>
                            <?php if($record->event_price != null): ?>
                                <li>
                                    <div class="block">
                                        <div class="tags">
                                            <a href="" class="tag ima-bg-green">
                                                <span>API Sync</span>
                                            </a>
                                        </div>
                                        <div class="block_content position-relative dashboard-history-wrap">
                                            <div class="num-new-records"><span class="numberCircle"><?php echo e($record->event_price); ?></span><span>New Records</span>
                                            </div>
                                            <h2 class="title">
                                                <a>Event Prices Update</a>
                                            </h2>
                                            <div class="byline">
                                                <span><?php echo e($record->created_at); ?></span> by <a>System automation</a>
                                            </div>
                                            <p class="excerpt dashboard-file-name">New Data Sync: <span> System generated automatically</span></p>
                                        </div>
                                    </div>
                                </li>
                            <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>