

<?php $__env->startSection('content'); ?>

    <div class="clearfix"></div>

    <div class="header-buttons-wrap">
        <a class="btn btn-app" href="/events-analysis">
            <i class="fa fa-bar-chart"></i> View Analysis
        </a>
    </div>

    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>IMA Events Summary</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                        This is a summary report of all events
                    </p>
                    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Event Name</th>
                                <th>Date</th>
                                <th>Start Time</th>
                                <th>Attendees</th>
                                <th>Total (A$)</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(url('events/' . $event->id)); ?>"><?php echo e($i); ?></a></td>
                                <td><a href="<?php echo e(url('events/' . $event->id)); ?>"><?php echo e($event->event_name); ?></a></td>
                                <td><a href="<?php echo e(url('events/' . $event->id)); ?>"><?php echo e(date('d-m-Y', strtotime($event->event_date))); ?></a></td>
                                <td class="text-uppercase"><a href="<?php echo e(url('events/' . $event->id)); ?>"><?php echo e($event->event_start_time); ?></a></td>
                                <td><a href="<?php echo e(url('events/' . $event->id)); ?>"><?php echo e($event->attendees_total); ?></a></td>
                                <td class="text-right"><a href="<?php echo e(url('events/' . $event->id)); ?>"><?php echo e($event->paid_total); ?></a></td>
                                <td>
                                    <a href="<?php echo e(url('events/' . $event->id)); ?>" class="event-status text-center">
                                        <?php if($event->event_status == "open"): ?>
                                            <span class="label label-success">Open</span>
                                        <?php endif; ?>
                                        <?php if($event->event_status == "closed"): ?>
                                            <span class="label label-info">Closed</span>
                                        <?php endif; ?>
                                        <?php if($event->event_status == "sold"): ?>
                                            <span class="label label-default">Sold out</span>
                                        <?php endif; ?>
                                    </a>
                                </td>
                                <td class="text-center">
                                    <a href="<?php echo e(url('events/' . $event->id)); ?>" class="" title="View"><span class="label btn-success"><i class="fa fa-search"></i> View</span></a>
                                    <a href="<?php echo e(url('event-details-print/' . $event->id)); ?>" class="" target="_blank" title="Print"><span class="label btn-dark"><i class="fa fa-print"></i> Print</span></a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>