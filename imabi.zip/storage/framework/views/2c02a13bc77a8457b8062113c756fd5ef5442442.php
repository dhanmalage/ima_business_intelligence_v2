

<?php $__env->startSection('content'); ?>

    <div class="clearfix"></div>

    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>IMA Donations Summary</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                        This is a summary report of all main donations
                    </p>
                    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Amount</th>
                            <th>Type</th>
                            <th>Reference</th>
                            <th>Anonymous</th>
                            <th>Date</th>
                            <th>Category</th>
                            <th>Actions</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(url('donations/' . $donation->id)); ?>"><?php echo e($i); ?></a></td>
                                <td class="text-right"><a href="<?php echo e(url('donations/' . $donation->id)); ?>"><?php echo e(number_format($donation->amount, 2 , '.' , ',' )); ?></a></td>
                                <td class="text-capitalize"><a href="<?php echo e(url('donations/' . $donation->id)); ?>"><?php echo e($donation->donation_type); ?></a></td>
                                <td><a href="<?php echo e(url('donations/' . $donation->id)); ?>"><?php echo e($donation->order_id); ?></a></td>
                                <td><a href="<?php echo e(url('donations/' . $donation->id)); ?>"><?php echo e($donation->anonymous); ?></a></td>
                                <td><a href="<?php echo e(url('donations/' . $donation->id)); ?>"><?php echo e($donation->date); ?></a></td>
                                <td><a href="<?php echo e(url('donations/' . $donation->id)); ?>"><?php echo e($donation->category); ?></a></td>
                                <td class="text-center">
                                    <a href="<?php echo e(url('donations/' . $donation->id)); ?>" class="" title="View"><span class="label btn-success"><i class="fa fa-search"></i> View</span></a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>