<?php $__env->startSection('content'); ?>

    <div class="page-title">
        <div class="title_left">
            <h3><?php echo e($event->event_name); ?> <small> Event #<?php echo e($event->event_id); ?> Detailed Report</small></h3>
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="header-buttons-wrap">
        <a class="btn btn-app" href="/events">
            <i class="fa fa-reply"></i> Events
        </a>
<!--
        <a class="btn btn-app" href="/ima-event/ima-event-email/<?php echo e($event->id); ?>">
            <i class="fa fa-envelope"></i> Emails
        </a>
        -->
    </div>

    <div class="clearfix"></div>

    <div class="row tile_count">

        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-user"></i> Attendees / Total</span>
            <div class="count"><?php echo e($event->attendees_total); ?></div>
            <span class="count_bottom"><i class="green">Number of people </i> </span>
        </div>
        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-dollar"></i> Total Amount</span>
            <div class="count"><?php echo e(number_format( $event->paid_total, 2 , '.' , ',' )); ?></div>
            <span class="count_bottom"><i class="green">Total amount received </i> </span>
        </div>
        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-calendar-o"></i> Event Date</span>
            <div class="count"><?php echo e(date('d/m/Y', strtotime($event->event_date))); ?></div>
        </div>
        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-clock-o"></i> Event Time</span>
            <div class="count text-uppercase"><?php echo e($event->event_start_time); ?></div>
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2><?php echo e($event->event_name); ?></h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                        This is a detailed report on <code><?php echo e($event->event_name); ?></code> as at <?php echo e(date('d/m/Y', strtotime($event->event_date))); ?>

                    </p>
                    <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Post Code</th>
                            <th>Reg Date</th>
                            <th># Attendees</th>
                            <th>Paid (A$)</th>
                            <th>How did</th>
                            <th>Reference</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $i = 1; $dc = 0; $dt = 0; ?>
                        <?php $__currentLoopData = $attendees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($detail->fname); ?></td>
                                <td><?php echo e($detail->lname); ?></td>
                                <td><?php echo e($detail->email); ?></td>
                                <td><?php echo e($detail->phone); ?></td>
                                <td><?php echo e($detail->post_code); ?></td>
                                <td><?php echo e(date('d-m-Y', strtotime($detail->date))); ?></td>
                                <td><?php echo e($detail->quantity); ?></td>
                                <td class="text-right"><?php echo e($detail->ticket_total); ?></td>
                                <td><?php echo e($detail->how_did); ?></td>
                                <td><?php echo e($detail->reference); ?></td>
                            </tr>

                            <?php if($detail->donation > 0): ?>
                                <?php
                                    $dc++;
                                    $dt = $dt + $detail->donation;
                                ?>
                            <?php endif; ?>

                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="page-title">
        <div class="title_left">
            <h3>Donations from "<?php echo e($event->event_name); ?>" registered users</h3>
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="row tile_count">
        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-user"></i> Number of Donations</span>
            <div class="count"><?php echo e($dc); ?></div>
            <span class="count_bottom"><i class="green">Number of people </i> </span>
        </div>
        <div class="col-md-3 col-sm-4 col-xs-6 tile_stats_count">
            <span class="count_top"><i class="fa fa-dollar"></i> Donation Total</span>
            <div class="count"><?php echo e(number_format( $dt, 2 , '.' , ',' )); ?></div>
            <span class="count_bottom"><i class="green">Total amount received </i> </span>
        </div>
    </div>

    <div class="clearfix"></div>

    <?php if($dc > 0): ?>

    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Donated Attendee Details</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                        All donations from  <code><?php echo e($event->event_name); ?></code> as at <?php echo e(date('d/m/Y', strtotime($event->event_date))); ?>

                    </p>
                    <table id="datatable" class="table table-striped table-bordered">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Post Code</th>
                            <th>Date</th>
                            <th>Donation</th>
                            <th>Reference</th>
                        </tr>
                        </thead>

                        <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $attendees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($detail->donation > 0): ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($detail->fname); ?></td>
                                    <td><?php echo e($detail->lname); ?></td>
                                    <td><?php echo e($detail->email); ?></td>
                                    <td><?php echo e($detail->phone); ?></td>
                                    <td><?php echo e($detail->post_code); ?></td>
                                    <td><?php echo e(date('d-m-Y', strtotime($detail->date))); ?></td>
                                    <td class="text-right"><?php echo e(number_format($detail->donation, 2 , '.' , ',' )); ?></td>
                                    <td><?php echo e($detail->reference); ?></td>
                                </tr>
                            <?php endif; ?>
                            <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="clearfix"></div>

    <div class="row">
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Event Donations Bar Chart</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                        This is a bar chart of <code><?php echo e($event->event_name); ?></code> event division by attendees
                    </p>
                    <div class="x_content evdtdonchart">
                        <div id="graphBarEventDonation"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Event Donations Doughnut Chart</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30">
                        This is a doughnut chart of <code><?php echo e($event->event_name); ?></code> event division by attendees
                    </p>
                    <div class="x_content evdtdonchart">
                        <canvas id="canvasDoughnutEventDonation"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php endif; ?>

    <div class="clearfix"></div>

    <div class="hide">
        <?php $__currentLoopData = $attendees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="open-event-detail" data-fname="<?php echo e($attendee->fname); ?>" data-donation="<?php echo e($attendee->donation); ?>"></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>