<html>

    <head>
        <title>IMA Business Intelligence</title>

        <link href="<?php echo e(url('vendor/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/nprogress/nprogress.css" rel="stylesheet')); ?>">
        <link href="<?php echo e(url('vendor/iCheck/skins/flat/green.css" rel="stylesheet')); ?>">
        <link href="<?php echo e(url('vendor/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('build/css/custom.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('css/styles.css')); ?>" rel="stylesheet">
    </head>

<body>

    <h3>IMA Business Intelligence Event Report</h3>

    <h2>Event Name: <?php echo e($event->event_name); ?></h2>
    <h2>Date: <?php echo e($event->event_date); ?></h2>
    <h2 class="text-uppercase">Time: <?php echo e($event->event_start_time); ?></h2>
    <h2>Attendees: <?php echo e($event->attendees_total); ?></h2>

    <table class="table table-striped table-bordered dt-responsive nowrap dataTable no-footer dtr-inline">
        <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Tickets</th>
                <th>Total ($)</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $attendees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($attendee->fname); ?></td>
                    <td><?php echo e($attendee->lname); ?></td>
                    <td><?php echo e($attendee->email); ?></td>
                    <td><?php echo e($attendee->phone); ?></td>
                    <td><?php echo e($attendee->quantity); ?></td>
                    <td class="text-right"><?php echo e($attendee->ticket_total); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($attendee->date))); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <script type="text/javascript">
        window.onload = function() { window.print(); }
    </script>

</body>
</html>