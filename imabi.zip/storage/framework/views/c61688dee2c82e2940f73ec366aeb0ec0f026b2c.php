<html>

    <head>
        <title>IMA Business Intelligence</title>

        <link href="<?php echo e(url('vendor/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/nprogress/nprogress.css" rel="stylesheet')); ?>">
        <link href="<?php echo e(url('vendor/iCheck/skins/flat/green.css" rel="stylesheet')); ?>">
        <link href="<?php echo e(url('vendor/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('vendor/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('build/css/custom.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(url('css/styles.css')); ?>" rel="stylesheet">
    </head>

<body>

    <h3>IMA Business Intelligence Report</h3>

    <h2>Event Name: <?php echo e($event->event_name); ?></h2>
    <h2>Date: <?php echo e($event->start_date); ?></h2>
    <h2>Time: <?php echo e($event->event_start_time); ?></h2>
    <h2>Attendees: <?php echo e($event->imabi_attendees_complete); ?></h2>

    <table class="table table-striped table-bordered dt-responsive nowrap dataTable no-footer dtr-inline">
        <thead>
            <tr>
                <th>Reg Date</th>
                <th>Pay Status</th>
                <th>Qty</th>
                <th>Paid</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $event_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(date('d-m-Y', strtotime($event_detail->date))); ?></td>
                    <td><?php echo e($event_detail->payment_status); ?></td>
                    <td><?php echo e($event_detail->quantity); ?></td>
                    <td>$<?php echo e($event_detail->amount_pd); ?></td>
                    <td><?php echo e($event_detail->fname); ?></td>
                    <td><?php echo e($event_detail->lname); ?></td>
                    <td><?php echo e($event_detail->email); ?></td>
                    <td><?php echo e($event_detail->phone); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <script type="text/javascript">
        window.onload = function() { window.print(); }
    </script>

</body>
</html>