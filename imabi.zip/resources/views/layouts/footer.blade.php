<!-- footer content -->
<footer>
    <div class="pull-right">
        ©2018 All Rights Reserved <a href="http://osmium.com.au">OSMIUM</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->