<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>IMA Business Intelligence Events Update</title>
</head>

<body>
IMA Business Intelligence system database successfully updated.
</body>

</html>