/**
 * Created by Osmium user on 6/13/2018.
 */
$(document).ready(function(){
    $(function() {
        $('.evdtdonchart').matchHeight(
            {
                byRow: false,
                property: 'height',
                target: null,
                remove: false
            }
        );
    });
});